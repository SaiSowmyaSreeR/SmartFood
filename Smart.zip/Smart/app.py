from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a strong secret key

# Path to SQLite database
DATABASE = 'database.db'


# ---------------------- Database Setup ---------------------- #
def init_db():
    if not os.path.exists(DATABASE):
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL
                )
            ''')
            conn.commit()


# ---------------------- Routes ---------------------- #
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
                conn.commit()
                flash("Registration successful!", "success")
                return redirect(url_for('home'))
            except sqlite3.IntegrityError:
                flash("Username already exists.", "danger")

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
            user = cursor.fetchone()

            if user:
                session['username'] = username
                flash("Login successful!", "success")
                return redirect(url_for('home'))
            else:
                flash("Invalid credentials", "danger")

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("Logged out successfully", "info")
    return redirect(url_for('home'))


# ---------------------- Other Pages ---------------------- #
@app.route('/contacts')
def contacts():
    return render_template('contacts.html')


@app.route('/icecream')
def icecream():
    return render_template('icecream.html')

@app.route('/biscuits')
def biscuits():
    return render_template('Biscuits.html')

@app.route('/burger')
def burger():
    return render_template('Burger.html')

@app.route('/chickenbiriyani')
def chickenbiriyani():
    return render_template('Chicken Biriyani.html')

@app.route('/chickenlalipop')
def chickenlalipop():
    return render_template('Chicken Lalipop.html')

@app.route('/chocklate')
def chocklate():
    return render_template('Chocklate.html')

@app.route('/frenchfries')
def frenchfries():
    return render_template('French Fries.html')

@app.route('/honeycake')
def honeycake():
    return render_template('Honey cake.html')

@app.route('/murukulu')
def murukulu():
    return render_template('Murukulu.html')

@app.route('/pizza')
def pizza():
    return render_template('Pizza.html')

@app.route('/sandwich')
def sandwich():
    return render_template('Sandwich.html')

@app.route('/vegbiriyani')
def vegbiriyani():
    return render_template('Veg Biriyani.html')

@app.route('/chips')
def chips():
    return render_template('Chips.html')

@app.route('/checkmix')
def checkmix():
    return render_template('CheckMix.html')

@app.route('/pulihora')
def pulihora():
    return render_template('PuliHora.html')

@app.route('/mood')
def mood():
    return render_template('Mood.html')


@app.route('/choice')
def choice():
    return render_template('Choice.html')


# ---------------------- Main ---------------------- #
if __name__ == '__main__':
    init_db()  # Only run once to create the DB
    app.run(debug=True)
